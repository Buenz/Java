// The Homework3 class that contains methods to be implemented in HW3
// Your name here

public class Homework3
{
    // This method takes two int arrays (as number vectors) and returns the
    // Euclidean distance between the two vectors.
    // Do not make any changes to this method!
    public double euclidean(double[] A, double[] B)
    {
        int n = A.length;
        double dist = 0;

        for (int i = 0; i < n; i++)
            dist += (A[i] - B[i]) * (A[i] - B[i]);

        return Math.sqrt(dist);
    }

    // This method takes as parameter an integer for the number of clusters, a
    // 2D double array for the cluster centroids, and a 2D double array for the
    // data set that contains test samples. It returns a 1D int array that contains
    // the cluster indices for all samples.
    public int[] assignSamples(int k, double[][] centroids, double[][] dataset)
    {
        int[] output= new int[dataset.length];
        double[] arr1=new double[centroids[0].length];
        double[] arr2=new double[dataset[0].length];
        double dist=0.0;
        int cluster=-1;

        for(int i=0;i<dataset.length;i++){
          double min= Double.MAX_VALUE;

          for(int j=0;j<dataset[0].length;j++){
            arr2[j]=dataset[i][j];
          }

          for(int q=0; q<centroids.length;q++){
            for(int z=0; z<centroids[0].length;z++){
              arr1[z]=centroids[q][z];
            }
            dist=euclidean(arr1, arr2);
            if(min>dist){
              min=dist;
              cluster=q;
            }
          }
          output[i]=cluster;
        }

        return output; // replace this statement with your own return
    }

    // This method takes as parameter an integer for the number of clusters, a 1D
    // int array that contains the cluster indices for all samples, and a 2D
    // double array for the data set that contains test samples. It returns a
    // 2D double array that contains the updated cluster centroids.
    public double[][] updateCentroids(int k, int[] clusters, double[][] dataset)
    {
        double [][] update= new double[k][dataset[0].length];

        for(int i=0; i<clusters.length;i++){
          for(int j=0;j<dataset[i].length;j++){   ////check this out!
            update[clusters[i]][j]+=dataset[i][j];
          }
        }

        ///calculate mean
        int sum=0;
        for(int k2=0;k2<update.length;k2++){

          for(int z=0;z<clusters.length;z++){
            if(k2==clusters[z]){sum++;}
          }
          for(int q=0;q<update[k2].length;q++){
            update[k2][q]=(double)update[k2][q]/(double)sum;
          }
          sum=0;
        }


        return update; // replace this statement with your own return
    }

    // This method takes as parameter an int array that contains the cluster indicies
    // for all samples, a 2D double array for the cluster centroids, and a 2D double
    // array for the data set that contains test samples. It returns the sum of squared
    // error (SSE) for the clusters.
    public double calculateSSE(int[] clusters, double[][] centroids, double[][] dataset)
    {
         double variation=0.0;

         for(int i=0;i<centroids.length;i++){
           for(int j=0;j<clusters.length;j++){
             for(int k=0; k<dataset[j].length && i==clusters[j]; k++){
               variation+= ((dataset[j][k]-centroids[clusters[j]][k])*
               (dataset[j][k]-centroids[clusters[j]][k]));
             }
           }
         }

        return variation; // replace this statement with your own return
    }

    // This method implements the k-means clustering algorithm. It takes an integer
    // for the number of clusters, a 2D double array for the cluster centroids, and
    // a 2D double array for the data set that contains test samples. It returns the
    // final SSE after the clustering process converges.
    // NOTE: This method should leverage the above methods in order to implement
    // the algorithm. It should NOT re-implement any functionalities that have been
    // implemented in the above methods.
    public double kMeans(int k, double[][] centroids, double[][] dataset)
    {
        int[] clust=assignSamples(k, centroids, dataset);
        double update[][]=updateCentroids(k, clust, dataset);
        clust=assignSamples(k, update, dataset);
        update=updateCentroids(k, clust, dataset);
        double variation=calculateSSE(clust, update, dataset);

        double temp=-1;
        do{
          temp=variation;
          clust=assignSamples(k, update, dataset);
          update=updateCentroids(k, clust, dataset);
          variation=calculateSSE(clust, update, dataset);
        }while(temp>variation);
        return variation; // replace this statement with your own return
    }
}
