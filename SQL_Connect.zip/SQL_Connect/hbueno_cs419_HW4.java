package connector;
import java.sql.*;

public class Main {
	public static void main(String[] args) throws Exception {

		try {
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/MyCompany", "root", "Steve#14n");

			if (con !=null) {
				System.out.println("Connected");
			}

			Statement stmt=con.createStatement();
			String sql = "insert into MyCompany.Department values (1, 'Marketing', 'Chicago, IL'),"
					+ " (2, 'Human Resources', 'Chicago, IL'),"
					+ " (3, 'IT', 'Chicago, IL')";

			String sql2 = "insert into MyCompany.Employee values (1, 'Peter Parker', 1,200000, 3),"
					+ " (2, 'Tony Stark', 4, 9999999,3),"
					+ " (3, 'Britney Spears', 2, 200000,3),"
					+ " (4, 'Christina Aguilera', 3, 200000,3),"
					+ " (5, 'Martha Nielsen', 1, 200000,2),"
					+ " (6, 'Tony Parker', 2, 200000,2),"
					+ " (7, 'Homer Simpson', 3, 200000,2),"
					+ " (8, 'Bart Simpson', 4, 200000,2),"
					+ " (9, 'Lisa Simpson', 1, 200000,1),"
					+ " (10, 'Michael Jordan', 2, 200000,1),"
					+ " (11, 'Larry Bird', 3, 200000,1),"
					+ " (12, 'LeBron James', 4, 200000,1)";

			String sql3 = "insert into MyCompany.Project values (1, 1, 'Laser Beam', 10000000, 2010), "
					+ "(2, 1, 'Sharks with Lasers', 2000000, 2015), "
					+ "(3, 1, 'Atomic Bomb', 2000000, 2015), "
					+ "(4, 2, 'Mind Control', 2000000, 2015), "
					+ "(5, 2, 'Rating System', 2000000, 2016), "
					+ "(6, 2, 'Artificial Intelligence', 2000000, 2016), "
					+ "(7, 3, 'Website Design', 2000000, 2016), "
					+ "(8, 3, 'Linux System', 2000000, 2010), "
					+ "(9, 3, 'Mobile App', 2000000, 2009) ";

			stmt.execute(sql);
			stmt.execute(sql2);
			stmt.execute(sql3);



			ResultSet rs=stmt.executeQuery("select start_year, min(budget) as minBudget, max(budget) as maxBudget, Avg(budget) as avgBudget " +
					"from MyCompany.Project " +
					"where start_year=2010");

			System.out.printf("%5s %10s  %9s %10s%n", "st_yr", "min", "max", "avg");
			while(rs.next()) {
				int startyear = rs.getInt("start_year");
				double minbudget = rs.getDouble("minBudget");
				double maxbudget = rs.getDouble("maxBudget");
				double avgbudget = rs.getDouble("avgBudget");
				System.out.printf("%5d %10.0f %10.0f %10.0f %n", startyear, minbudget, maxbudget, avgbudget);

			}
			System.out.println();

			ResultSet rs2=stmt.executeQuery("select D.Name as dept, avg(E.Salary) as avg " +
					"from MyCompany.Department as D, MyCompany.Employee as E " +
					"where D.Did=E.DepartmentID and D.name='Marketing'");

			System.out.printf("%10s %10s%n", "Name", "avgSalary");
			while(rs2.next()) {
				String name = rs2.getString("dept");
				double budget = rs2.getDouble("avg");

				System.out.printf("%10s %10.0f%n", name, budget);

			}
			System.out.println();

			ResultSet rs3=stmt.executeQuery("select * " +
					"from MyCompany.Project " +
					"order by start_year");

			System.out.printf("%4s %4s %15s %10s %5s%n", "Pid", "ID", "name", "budget", "srtyr");
			while(rs3.next()) {
				int pid = rs3.getInt("Pid");
				int id = rs3.getInt("DepartmentID");
				String name =  rs3.getString("name");
				double budget =  rs3.getDouble("budget");
				int str_yr =  rs3.getInt("start_year");

				System.out.printf("%4d %4d %15s %10.0f %5d%n", pid, id, name, budget, str_yr);
			}
			System.out.println();

			ResultSet rs4=stmt.executeQuery("select E.erank, round(avg(E.Salary)) as avg " +
					"from MyCompany.Employee as E " +
					"group by erank order by erank");

			System.out.printf("%4s %10s%n", "rank", "avg");
			while(rs4.next()) {
				int rank = rs4.getInt("erank");
				double avg = rs4.getDouble("avg");


				System.out.printf("%4d %10.0f%n", rank, avg);
			}
			System.out.println();

			ResultSet rs5=stmt.executeQuery("select E.name as ename, E.Eid " +
					"from MyCompany.Employee as E, MyCompany.Department as D " +
					"where E.DepartmentID=D.Did and D.name='IT' and " +
					"E.salary> " +
					"(select round(avg(E.salary)) " +
					"from MyCompany.Employee as E, MyCompany.Department as D " +
					"where E.DepartmentID=D.Did and D.name='Marketing')");

			System.out.printf("%10s %5s%n", "name", "Eid");
			while(rs5.next()) {
				String name = rs5.getString("ename");
				int id = rs5.getInt("Eid");


				System.out.printf("%10s %5d%n", name, id);
			}
			System.out.println();

			con.close();

		}catch(Exception e) {
			System.out.println(e);
		}
	}


}
