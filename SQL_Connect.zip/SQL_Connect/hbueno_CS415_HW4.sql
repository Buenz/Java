/*Task Description: Consider the following relations for a company:

Department (Did: integer, name: string, location: string)
Employee (Eid: integer, name: string, erank: integer, salary: real, DepartmentID, integer)
Project (Pid: integer, DepartmentID: integer, name: string, budget: real, start year: integer)

The “DepartmentID” fields in both Employee and Project are foreign keys referencing the “Did” 
field of the Department table. The rank of employee is an integer value between 1 and 3.*/


/*Set global time_zone='+3:00';   to make SQL work on JAVA had time stuff*/  

drop database MyCompany;

create database MyCompany;

CREATE TABLE MyCompany.Department(
Did	integer not null,
name	varchar(30) not null,
lacation	varchar(30) not null,

primary key(Did)
);

CREATE TABLE MyCompany.Employee(

Eid	integer	not null, 
name	varchar(30)	not null, 
erank	integer	not null, 
salary	real	not null, 
DepartmentID	integer	not null, 

primary key(Eid), 
foreign key(DepartmentID) references Department(Did)
);

Create table MyCompany.Project(
Pid	integer	not null, 
DepartmentID	integer	not null, 
name	varchar(30)	not null, 
budget	real	not null, 
start_year	integer	not null, 
primary key(Pid),
foreign key(DepartmentID) references Department(Did)
);

select * from MyCompany.Department;
select * from MyCompany.Project;
select * from MyCompany.Employee;
/*1*/
select start_year, min(budget) as minBudget, max(budget) as maxBudget, Avg(budget) as avgBudget
from MyCompany.Project
where start_year=2010;
/*2*/
select D.Name, avg(E.Salary)
from MyCompany.Department as D, MyCompany.Employee as E
where D.Did=E.DepartmentID and D.name='Marketing';
/*3*/
select * 
from MyCompany.Project
order by start_year;
/*4*/
select E.erank, round(avg(E.Salary)) as avg
from MyCompany.Employee as E
group by erank order by erank;
/*5*/
select E.name as ename, E.Eid
from MyCompany.Employee as E, MyCompany.Department as D
where E.DepartmentID=D.Did and D.name='IT' and
E.salary>
(select round(avg(E.salary))
from MyCompany.Employee as E, MyCompany.Department as D
where E.DepartmentID=D.Did and D.name='Marketing');



